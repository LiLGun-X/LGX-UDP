#!/usr/bin/env bash
# UDP Custom Panel — clean reinstall / upgrade script
# - Removes any existing Node.js/npm install first
# - Installs a fresh current Node.js LTS (20.x) from NodeSource
# - Deploys the fixed panel files (server.js + public/)
# - Installs npm dependencies
# - Restarts the systemd service
set -euo pipefail

PANEL_DIR="/opt/udp-custom-panel"
NODE_MAJOR="20"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ "$(id -u)" -ne 0 ]; then
  echo "Please run this script as root (sudo bash install.sh)" >&2
  exit 1
fi

echo "==> Stopping panel service (if running)..."
systemctl stop udp-custom-panel 2>/dev/null || true

echo "==> Checking for existing Node.js/npm installation..."
if command -v node >/dev/null 2>&1; then
  echo "    Found: $(node -v) at $(command -v node)"
else
  echo "    No existing Node.js found."
fi

echo "==> Removing existing Node.js/npm (apt + nodesource leftovers)..."
apt-get remove -y --purge nodejs npm libnode-dev libnode72 >/dev/null 2>&1 || true
apt-get autoremove -y >/dev/null 2>&1 || true
rm -rf /usr/lib/node_modules /usr/local/lib/node_modules /usr/local/bin/node /usr/local/bin/npm
rm -f /etc/apt/sources.list.d/nodesource.list

echo "==> Installing Node.js ${NODE_MAJOR}.x LTS from NodeSource..."
apt-get update -y
apt-get install -y ca-certificates curl gnupg
curl -fsSL https://deb.nodesource.com/setup_${NODE_MAJOR}.x | bash -
apt-get install -y nodejs

echo "==> Verifying Node.js installed..."
if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: node was not installed correctly. Aborting." >&2
  exit 1
fi
node -v

echo "==> Verifying npm is present (NodeSource's nodejs package doesn't always pull it in)..."
if ! command -v npm >/dev/null 2>&1; then
  echo "    npm missing after nodejs install — attempting fallback #1: apt-get install npm"
  apt-get install -y npm || true
fi
if ! command -v npm >/dev/null 2>&1; then
  echo "    still missing — attempting fallback #2: corepack (bundled with Node 20)"
  if command -v corepack >/dev/null 2>&1; then
    corepack enable || true
  fi
fi
if ! command -v npm >/dev/null 2>&1; then
  echo "    still missing — attempting fallback #3: official npm install script"
  curl -qL https://www.npmjs.com/install.sh | sh || true
fi
if ! command -v npm >/dev/null 2>&1; then
  echo "ERROR: npm could not be installed by any method. Please check network/apt access and install npm manually, then re-run this script." >&2
  exit 1
fi
npm -v

echo "==> Deploying panel files to ${PANEL_DIR}..."
mkdir -p "${PANEL_DIR}/public"
if [ ! -f "${SCRIPT_DIR}/server.js" ]; then
  echo "ERROR: ${SCRIPT_DIR}/server.js not found. Run this script from inside the unzipped folder." >&2
  exit 1
fi
cp -f "${SCRIPT_DIR}/server.js" "${PANEL_DIR}/server.js"
cp -f "${SCRIPT_DIR}/public/app.js" "${PANEL_DIR}/public/app.js"
# index.html and style.css are left untouched if already present; copy only if missing
[ -f "${PANEL_DIR}/public/index.html" ] || cp -f "${SCRIPT_DIR}/public/index.html" "${PANEL_DIR}/public/index.html" 2>/dev/null || true
[ -f "${PANEL_DIR}/public/style.css" ] || cp -f "${SCRIPT_DIR}/public/style.css" "${PANEL_DIR}/public/style.css" 2>/dev/null || true

echo "==> Checking system commands the panel relies on..."
MISSING_CMDS=()
for c in systemctl ss openssl useradd userdel usermod chage passwd journalctl pkill; do
  command -v "$c" >/dev/null 2>&1 || MISSING_CMDS+=("$c")
done
if [ ${#MISSING_CMDS[@]} -gt 0 ]; then
  echo "WARNING: the following commands the panel depends on were not found: ${MISSING_CMDS[*]}"
  echo "         Related panel features (user management, logs, service control) will fail until these are installed."
fi

echo "==> Installing npm dependencies..."
cd "${PANEL_DIR}"
rm -rf node_modules package-lock.json
if [ ! -f package.json ]; then
  npm init -y >/dev/null
fi
# Pin Express to v4 explicitly — Express 5's stricter path-to-regexp rejects
# the app.get("*", ...) wildcard style used elsewhere unless written differently,
# so pinning avoids a future "npm install" silently pulling in a breaking major version.
npm install express@4 systeminformation@latest

echo "==> Setting up panel login config..."
PANEL_CFG_DIR="/etc/udp-custom-panel"
PANEL_CFG_FILE="${PANEL_CFG_DIR}/panel.json"
GENERATED_PASSWORD=""
if [ ! -f "${PANEL_CFG_FILE}" ]; then
  echo "    No existing panel.json found — creating one with a fresh admin account."
  mkdir -p "${PANEL_CFG_DIR}"
  GENERATED_PASSWORD="$(openssl rand -base64 18 | tr -dc 'A-Za-z0-9' | head -c 20)"
  SALT="$(openssl rand -hex 16)"
  # scrypt hash generated the same way server.js does it (crypto.scryptSync, 64-byte key), hex-encoded
  HASH="$(node -e "const c=require('crypto');process.stdout.write(c.scryptSync(process.argv[1],process.argv[2],64).toString('hex'))" "${GENERATED_PASSWORD}" "${SALT}")"
  cat > "${PANEL_CFG_FILE}" <<EOF
{
  "user": "admin",
  "passwordSalt": "${SALT}",
  "passwordHash": "${HASH}"
}
EOF
  chmod 600 "${PANEL_CFG_FILE}"
else
  echo "    Existing panel.json found — leaving login credentials as-is."
fi

echo "==> Setting up systemd service..."
if [ ! -f /etc/systemd/system/udp-custom-panel.service ]; then
  echo "    No existing unit file found — creating /etc/systemd/system/udp-custom-panel.service"
  cat > /etc/systemd/system/udp-custom-panel.service <<EOF
[Unit]
Description=UDP Custom Web Panel
After=network.target

[Service]
Type=simple
WorkingDirectory=${PANEL_DIR}
ExecStart=$(command -v node) ${PANEL_DIR}/server.js
Restart=always
RestartSec=3
User=root
Environment=PANEL_PORT=2050

[Install]
WantedBy=multi-user.target
EOF
else
  echo "    Existing unit file found — leaving it as-is."
fi

echo "==> Restarting panel service..."
systemctl daemon-reload
systemctl enable udp-custom-panel
systemctl restart udp-custom-panel

sleep 2
echo "==> Service status:"
systemctl status udp-custom-panel --no-pager -l || true

echo ""
echo "Done. Node $(node -v) is now installed and the panel has been redeployed."
if [ -n "${GENERATED_PASSWORD}" ]; then
  echo ""
  echo "=================================================================="
  echo "  A new admin login was created (this password is shown ONCE):"
  echo "    Username: admin"
  echo "    Password: ${GENERATED_PASSWORD}"
  echo "  Save it now — the panel only stores a hash, not the plaintext."
  echo "  You can change it later from Settings inside the panel."
  echo "=================================================================="
fi
echo "Check logs with: journalctl -u udp-custom-panel -n 50 --no-pager"
