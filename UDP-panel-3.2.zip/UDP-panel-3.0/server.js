const express=require("express"),fs=require("fs"),path=require("path"),crypto=require("crypto"),{execFile,execFileSync,spawn}=require("child_process"),si=require("systeminformation");
const app=express();app.disable("x-powered-by");app.use(express.json({limit:"32kb"}));
const APP=__dirname,CFG=process.env.PANEL_CONFIG||"/etc/udp-custom-panel/panel.json",UDPCFG="/root/udp/config.json",PORT=Number(process.env.PANEL_PORT||2050),sessions=new Map(),attempts=new Map();
const run=(c,a=[],t=8000)=>new Promise((ok,no)=>execFile(c,a,{timeout:t,maxBuffer:524288},(e,o,s)=>e?no(Error((s||o||e.message).trim())):ok((o||"").trim())));
function cfg(){return JSON.parse(fs.readFileSync(CFG,"utf8"))} function save(c){fs.writeFileSync(CFG,JSON.stringify(c,null,2)+"\n",{mode:0o600})}
let ipCache={value:null,at:0};
async function publicIP(){if(ipCache.value&&Date.now()-ipCache.at<6e5)return ipCache.value;try{const v=await run("curl",["-s","--max-time","4","https://api.ipify.org"]);if(v&&/^[\d.:a-fA-F]+$/.test(v)){ipCache={value:v,at:Date.now()};return v}}catch{}return null}

// --- Online-session tracker ---------------------------------------------
// udp-custom's own log lines are the only source of per-user connection data:
//   "[src:IP:PORT] [user:NAME] Client connected"
//   "[src:IP:PORT] ... Client disconnected"   (no username on this line — matched by src)
// State lives in memory only: it resets if the panel restarts, and rebuilds
// itself from new connect/disconnect lines as they happen. It does NOT
// reflect sessions that were already open before the panel started, until
// the next disconnect/connect for that session is logged.
const srcToUser=new Map();      // "ip:port" -> username
const userSessions=new Map();   // username -> Set of "ip:port" currently connected
function trackConnect(src,user){
  srcToUser.set(src,user);
  if(!userSessions.has(user))userSessions.set(user,new Set());
  userSessions.get(user).add(src);
}
function trackDisconnect(src){
  const user=srcToUser.get(src);
  if(!user)return;
  srcToUser.delete(src);
  const set=userSessions.get(user);
  if(set){set.delete(src);if(set.size===0)userSessions.delete(user)}
}
function parseJournalLine(line){
  let m=line.match(/\[src:([^\]]+)\]\s*\[user:([^\]]+)\]\s*Client connected/);
  if(m){trackConnect(m[1],m[2]);return}
  m=line.match(/\[src:([^\]]+)\][^\n]*Client disconnected/);
  if(m){trackDisconnect(m[1]);return}
}
function startOnlineTracker(){
  const p=spawn("journalctl",["-u","udp-custom","-f","-n","0","--no-pager","-o","cat"],{stdio:["ignore","pipe","pipe"]});
  let buf="";
  p.stdout.on("data",chunk=>{
    buf+=chunk.toString("utf8");
    const lines=buf.split("\n");
    buf=lines.pop(); // keep any incomplete trailing line for next chunk
    for(const line of lines)parseJournalLine(line);
  });
  p.stderr.on("data",chunk=>{console.error("[online-tracker] journalctl stderr:",chunk.toString("utf8").trim())});
  p.on("exit",(code)=>{console.error(`[online-tracker] journalctl exited (code ${code}) — restarting tail in 3s`);setTimeout(startOnlineTracker,3000)});
  p.on("error",(err)=>{console.error("[online-tracker] failed to spawn journalctl:",err.message);setTimeout(startOnlineTracker,3000)});
}
startOnlineTracker();
function onlineInfo(username){const set=userSessions.get(username);return{online:!!(set&&set.size>0),sessions:set?set.size:0}}

function hp(p,s){return crypto.scryptSync(p,s,64)} function valid(p,c){if(typeof p!=="string")return false;const a=hp(p,c.passwordSalt),b=Buffer.from(c.passwordHash,"hex");return a.length===b.length&&crypto.timingSafeEqual(a,b)}
function ip(req){return String(req.headers["x-forwarded-for"]||req.socket.remoteAddress||"").split(",")[0].trim()}
function limited(x){let a=attempts.get(x),n=Date.now();if(!a||n-a.first>9e5){a={first:n,count:0,until:0};attempts.set(x,a)}return a.until>n}
function fail(x){let a=attempts.get(x)||{first:Date.now(),count:0,until:0};a.count++;if(a.count>=8)a.until=Date.now()+9e5;attempts.set(x,a)}
// Real auth — enforced on every protected route. (Previous debug bypass removed: it granted admin access with no token.)
function auth(req,res,next){const t=req.headers.authorization?.replace(/^Bearer\s+/i,"");const s=t&&sessions.get(t);if(!s)return res.status(401).json({error:"Unauthorized"});if(Date.now()-s.created>432e5){sessions.delete(t);return res.status(401).json({error:"Session expired"})}req.session=s;next()}
async function svc(n){try{const state=await run("systemctl",["is-active",n]),enabled=await run("systemctl",["is-enabled",n]).catch(()=>"disabled");return{active:state==="active",state,enabled}}catch{return{active:false,state:"unknown",enabled:"unknown"}}}
const safe=u=>typeof u==="string"&&/^[a-zA-Z0-9_-]{4,12}$/.test(u);
function users(){let t="";try{t=fs.readFileSync("/etc/passwd","utf8")}catch{return[]}return t.split("\n").map(l=>{const p=l.split(":");if(p.length<7||p[5]!=="/home/"+p[0]||p[6]!=="/bin/false"||["syslog","hwid","token"].some(x=>p[0].includes(x)))return null;const q=(p[4]||"").split(",");let exp="";try{exp=execFileSync("chage",["-l",p[0]],{encoding:"utf8"}).split("\n").find(x=>x.startsWith("Account expires"))?.split(": ").slice(1).join(": ")||""}catch{}let days=null,expired=false;if(exp&&exp.toLowerCase()!=="never"){const d=new Date(exp);if(!isNaN(d)){days=Math.max(0,Math.ceil((d-Date.now())/864e5));expired=d<Date.now()}}let blocked=false;try{blocked=execFileSync("passwd",["--status",p[0]],{encoding:"utf8"}).split(/\s+/)[1]!=="P"}catch{}return{username:p[0],password:q.slice(1).join(",")||"",limit:Number(q[0])||0,expires:exp,days,expired,blocked}}).filter(Boolean)}
app.use((q,r,n)=>{r.setHeader("X-Content-Type-Options","nosniff");r.setHeader("X-Frame-Options","DENY");r.setHeader("Referrer-Policy","no-referrer");n()});
app.post("/api/login",(q,r)=>{const x=ip(q);if(limited(x))return r.status(429).json({error:"Too many login attempts. Try again in 15 minutes."});const c=cfg();if(!valid(q.body?.password,c)||q.body?.username!==c.user){fail(x);return r.status(401).json({error:"Invalid username or password"})}attempts.delete(x);const t=crypto.randomBytes(32).toString("hex");sessions.set(t,{user:c.user,created:Date.now(),ip:x});r.json({token:t})});
app.post("/api/logout",auth,(q,r)=>{sessions.delete(q.headers.authorization.replace(/^Bearer\s+/i,""));r.json({ok:true})});
app.post("/api/account/password",auth,(q,r)=>{try{const c=cfg(),{currentPassword,newPassword}=q.body||{};if(!valid(currentPassword,c))return r.status(400).json({error:"Current password is incorrect"});if(typeof newPassword!=="string"||!/^[a-zA-Z0-9!@#$%^&*_.-]{8,64}$/.test(newPassword))return r.status(400).json({error:"New password must be 8-64 allowed characters"});const s=crypto.randomBytes(16).toString("hex");c.passwordSalt=s;c.passwordHash=hp(newPassword,s).toString("hex");save(c);sessions.clear();r.json({ok:true})}catch(e){r.status(500).json({error:e.message})}});
app.get("/api/overview",auth,async(q,r)=>{try{const[a,m,f,n,o,t,u,g,detectedIP]=await Promise.all([si.currentLoad(),si.mem(),si.fsSize(),si.networkStats(),si.osInfo(),si.time(),svc("udp-custom"),svc("udpgw"),publicIP()]);const d=f.find(x=>x.mount==="/")||f[0]||{},av=Number(m.available||m.total-m.used),s=await run("ss",["-H","-u"]).catch(()=>"");const sockets=s?s.split("\n").filter(Boolean).length:0;const kb=x=>Math.round(x||0);let listenPort=null;try{listenPort=Number(String(JSON.parse(fs.readFileSync(UDPCFG,"utf8")).listen||"").replace(":",""))||null}catch{}const c=cfg(),panelHost=c.panelHost||"";r.json({cpu:+a.currentLoad.toFixed(1),cpuCores:o.cpus||require("os").cpus().length,ram:+(((m.total-av)/m.total)*100).toFixed(1),ramUsed:kb(m.total-av),ramAvailable:kb(av),ramTotal:kb(m.total),disk:+(d.use||0).toFixed(1),diskUsed:kb(d.used),diskTotal:kb(d.size),rx:n.reduce((x,y)=>x+(y.rx_sec||0),0),tx:n.reduce((x,y)=>x+(y.tx_sec||0),0),uptime:t.uptime,hostname:o.hostname,platform:o.platform,arch:o.arch,udpCustom:u,udpgw:g,udpSockets:sockets,listenPort,detectedIP,panelHost,connectHost:panelHost||detectedIP||o.hostname})}catch(e){r.status(500).json({error:e.message})}});
app.put("/api/settings/host",auth,(q,r)=>{try{const h=String(q.body?.panelHost||"").trim();if(h&&!/^[a-zA-Z0-9.\-:]{1,253}$/.test(h))return r.status(400).json({error:"Invalid host/domain format"});const c=cfg();c.panelHost=h;save(c);r.json({ok:true,panelHost:h})}catch(e){r.status(500).json({error:e.message})}});
app.get("/api/config",auth,(q,r)=>{try{r.json(JSON.parse(fs.readFileSync(UDPCFG,"utf8")))}catch(e){r.status(500).json({error:e.message})}});
app.put("/api/config",auth,async(q,r)=>{try{const x=q.body||{},p=Number(String(x.listen||"").replace(":","")),sb=Number(x.stream_buffer),rb=Number(x.receive_buffer);if(!Number.isInteger(p)||p<1||p>65535||!Number.isInteger(sb)||sb<1048576||sb>268435456||!Number.isInteger(rb)||rb<1048576||rb>268435456)return r.status(400).json({error:"Invalid port or buffer (1-256 MB)"});const c={listen:":"+p,stream_buffer:sb,receive_buffer:rb,auth:{mode:"passwords"}};fs.copyFileSync(UDPCFG,UDPCFG+".bak");fs.writeFileSync(UDPCFG,JSON.stringify(c,null,2)+"\n",{mode:0o600});await run("systemctl",["restart","udp-custom"]);r.json({ok:true,config:c,status:await svc("udp-custom")})}catch(e){r.status(500).json({error:e.message})}});
app.post("/api/service/:name/:action",auth,async(q,r)=>{const n={udp:"udp-custom",udpgw:"udpgw"}[q.params.name],a=q.params.action;if(!n||!["start","stop","restart"].includes(a))return r.status(400).json({error:"Invalid service/action"});try{await run("systemctl",[a,n]);r.json({ok:true,status:await svc(n)})}catch(e){r.status(500).json({error:e.message})}});
app.get("/api/logs/:name",auth,async(q,r)=>{const n={udp:"udp-custom",udpgw:"udpgw",panel:"udp-custom-panel"}[q.params.name];if(!n)return r.status(400).json({error:"Invalid log target"});try{r.json({log:await run("journalctl",["-u",n,"-n","200","--no-pager","-o","short-iso"],1e4)})}catch(e){r.status(500).json({error:e.message})}});
app.get("/api/online",auth,(q,r)=>{const list=[...userSessions.entries()].map(([username,set])=>({username,sessions:set.size}));r.json({online:list,totalUsers:list.length,totalSessions:list.reduce((a,x)=>a+x.sessions,0)})});
app.get("/api/users",auth,(q,r)=>r.json({users:users().map(u=>({...u,...onlineInfo(u.username)}))}));
app.post("/api/users",auth,async(q,r)=>{const{x,password,days,limit}=q.body||{},username=x,d=Number(days),l=Number(limit);if(!safe(username)||typeof password!=="string"||!/^[a-zA-Z0-9]{4,12}$/.test(password))return r.status(400).json({error:"Username 4-12 (A-Z a-z 0-9 _ -), password 4-12 alphanumeric"});if(!Number.isInteger(d)||d<1||d>360||!Number.isInteger(l)||l<1||l>999)return r.status(400).json({error:"Days 1-360 and limit 1-999"});if(users().some(u=>u.username===username))return r.status(409).json({error:"User already exists"});try{const e=new Date(Date.now()+d*864e5).toISOString().slice(0,10),h=execFileSync("openssl",["passwd","-6",password],{encoding:"utf8"}).trim();await run("useradd",["-M","-s","/bin/false","-e",e,"-K",`PASS_MAX_DAYS=${d}`,"-p",h,"-c",`${l},${password}`,username]);r.json({ok:true,user:users().find(u=>u.username===username)})}catch(e){r.status(500).json({error:e.message})}});
app.post("/api/users/:u/:a",auth,async(q,r)=>{const u=q.params.u,a=q.params.a;if(!safe(u)||!users().some(x=>x.username===u))return r.status(404).json({error:"User not found"});try{if(a==="delete")await run("userdel",["--force",u]);else if(a==="block"){await run("pkill",["-u",u]).catch(()=>{});await run("usermod",["-L",u])}else if(a==="unblock")await run("usermod",["-U",u]);else if(a==="renew"){const d=Number(q.body?.days);if(!Number.isInteger(d)||d<1||d>360)return r.status(400).json({error:"Days 1-360"});await run("chage",["-E",new Date(Date.now()+d*864e5).toISOString().slice(0,10),u])}else return r.status(400).json({error:"Invalid action"});r.json({ok:true,user:users().find(x=>x.username===u)||null})}catch(e){r.status(500).json({error:e.message})}});
app.post("/api/reboot",auth,(q,r)=>{r.json({ok:true,message:"Reboot scheduled"});setTimeout(()=>run("systemctl",["reboot"]).catch(()=>{}),800)});
app.use(express.static(path.join(APP,"public")));app.get(/.*/,(q,r)=>r.sendFile(path.join(APP,"public","index.html")));
app.listen(PORT,"0.0.0.0",()=>console.log(`UDP Custom Panel listening on :${PORT}`));
