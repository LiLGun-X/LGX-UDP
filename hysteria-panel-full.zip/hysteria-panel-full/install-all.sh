#!/bin/bash
set -e

echo "=============================================="
echo " Hysteria 1 + BadVPN + Panel — full installer"
echo "=============================================="
echo

# ---- Config -----------------------------------------------------------
PANEL_DIR="/opt/hysteria-panel"
HY_DIR="/etc/hysteria"
HY_VERSION="v1.3.5"
HY_LISTEN_PORT=20000
PANEL_PORT=2050
PANEL_USER="admin"
PANEL_PASS="admin"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "== [1/9] Base packages =="
apt update -y
apt install -y curl wget unzip build-essential cmake git openssl iptables-persistent

# ---- 2. Hysteria 1 binary ----------------------------------------------
echo "== [2/9] Hysteria 1 ($HY_VERSION) =="
if [ ! -f /usr/local/bin/hysteria ]; then
  wget -O /usr/local/bin/hysteria "https://github.com/apernet/hysteria/releases/download/${HY_VERSION}/hysteria-linux-amd64"
  chmod +x /usr/local/bin/hysteria
else
  echo "hysteria binary already present, skipping download."
fi

mkdir -p "$HY_DIR"
if [ ! -f "$HY_DIR/server.crt" ]; then
  openssl req -x509 -nodes -newkey rsa:2048 \
    -keyout "$HY_DIR/server.key" -out "$HY_DIR/server.crt" \
    -subj "/CN=bing.com" -days 36500
else
  echo "cert already exists, skipping."
fi

if [ ! -f "$HY_DIR/config.json" ]; then
  cat > "$HY_DIR/config.json" << EOF
{
  "listen": ":${HY_LISTEN_PORT}",
  "protocol": "udp",
  "cert": "${HY_DIR}/server.crt",
  "key": "${HY_DIR}/server.key",
  "up_mbps": 100,
  "down_mbps": 100,
  "obfs": "changeme-obfs",
  "auth": {
    "mode": "external",
    "config": {
      "http": "http://127.0.0.1:9091/verify"
    }
  }
}
EOF
else
  echo "config.json already exists — leaving it, but forcing auth mode to external so the panel can manage users."
  python3 - << 'PYEOF'
import json
p = "/etc/hysteria/config.json"
with open(p) as f:
    c = json.load(f)
c["auth"] = {"mode": "external", "config": {"http": "http://127.0.0.1:9091/verify"}}
with open(p, "w") as f:
    json.dump(c, f, indent=2)
PYEOF
fi

if [ ! -f "$HY_DIR/users.json" ]; then
  cat > "$HY_DIR/users.json" << 'EOF'
{
  "users": []
}
EOF
fi

cat > /etc/systemd/system/hysteria-server.service << 'EOF'
[Unit]
Description=Hysteria Server Service
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/hysteria server --config /etc/hysteria/config.json
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# ---- 3. badvpn-udpgw (built from source, named badvpn7300) -------------
echo "== [3/9] badvpn-udpgw (build from source) =="
if [ ! -f /usr/local/bin/badvpn-udpgw ]; then
  rm -rf /tmp/badvpn-build-src
  git clone --depth 1 https://github.com/ambrop72/badvpn.git /tmp/badvpn-build-src
  mkdir -p /tmp/badvpn-build-src/build
  cd /tmp/badvpn-build-src/build
  cmake .. -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1
  make
  cp udpgw/badvpn-udpgw /usr/local/bin/badvpn-udpgw
  cd "$SCRIPT_DIR"
  rm -rf /tmp/badvpn-build-src
else
  echo "badvpn-udpgw already built, skipping."
fi

cat > /etc/systemd/system/badvpn7300.service << 'EOF'
[Unit]
Description=BadVPN UDP Gateway (port 7300)
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 1000
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# ---- 4. Node.js ----------------------------------------------------------
echo "== [4/9] Node.js =="
if ! command -v node >/dev/null 2>&1; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt install -y nodejs
else
  echo "node already installed: $(node -v)"
fi

# ---- 5. Panel files --------------------------------------------------
echo "== [5/9] Installing panel to $PANEL_DIR =="
mkdir -p "$PANEL_DIR"
cp -r "$SCRIPT_DIR"/* "$PANEL_DIR"/
cd "$PANEL_DIR"
npm install --omit=dev --no-audit --no-fund

# ---- 6. Panel login config -------------------------------------------
echo "== [6/9] Panel login config =="
mkdir -p /etc/hysteria-panel
if [ ! -f /etc/hysteria-panel/panel.json ]; then
  node - << EOF
const crypto = require("crypto");
const fs = require("fs");
const salt = crypto.randomBytes(16).toString("hex");
const hash = crypto.scryptSync("${PANEL_PASS}", salt, 64).toString("hex");
const cfg = { user: "${PANEL_USER}", passwordSalt: salt, passwordHash: hash, panelHost: "" };
fs.writeFileSync("/etc/hysteria-panel/panel.json", JSON.stringify(cfg, null, 2) + "\n", { mode: 0o600 });
console.log("panel.json created");
EOF
else
  echo "panel.json already exists, leaving credentials as-is."
fi

# ---- 7. systemd services for auth-server + panel ------------------------
echo "== [7/9] systemd services (auth server + panel) =="
cat > /etc/systemd/system/hysteria-auth.service << EOF
[Unit]
Description=Hysteria Auth Server (multiuser, expiry, device limit)
After=network.target

[Service]
Type=simple
Environment=USERS_FILE=${HY_DIR}/users.json
Environment=SESSIONS_FILE=${HY_DIR}/sessions.json
Environment=AUTH_PORT=9091
ExecStart=$(command -v node) ${PANEL_DIR}/auth-server.js
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/hysteria-panel.service << EOF
[Unit]
Description=Hysteria Management Panel
After=network.target

[Service]
Type=simple
WorkingDirectory=${PANEL_DIR}
Environment=PANEL_CONFIG=/etc/hysteria-panel/panel.json
Environment=USERS_FILE=${HY_DIR}/users.json
Environment=SESSIONS_FILE=${HY_DIR}/sessions.json
Environment=PANEL_PORT=${PANEL_PORT}
ExecStart=$(command -v node) ${PANEL_DIR}/server.js
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

# ---- 8. Firewall --------------------------------------------------------
echo "== [8/9] Firewall rules =="
iptables -C INPUT -p udp --dport "$HY_LISTEN_PORT" -j ACCEPT 2>/dev/null || iptables -A INPUT -p udp --dport "$HY_LISTEN_PORT" -j ACCEPT
iptables -C INPUT -p tcp --dport "$PANEL_PORT" -j ACCEPT 2>/dev/null || iptables -A INPUT -p tcp --dport "$PANEL_PORT" -j ACCEPT
netfilter-persistent save

# ---- 9. Start everything -------------------------------------------------
echo "== [9/9] Enabling and starting services =="
systemctl daemon-reload
systemctl enable --now hysteria-server.service
systemctl enable --now badvpn7300.service
systemctl enable --now hysteria-auth.service
systemctl enable --now hysteria-panel.service

VPS_IP=$(curl -s -4 ifconfig.me || hostname -I | awk '{print $1}')

echo
echo "=============================================="
echo " Done."
echo "=============================================="
echo "Panel:     http://${VPS_IP}:${PANEL_PORT}"
echo "Login:     ${PANEL_USER} / ${PANEL_PASS}"
echo "  -> change this from the panel's Settings page once you're in."
echo
echo "Hysteria server config: ${HY_DIR}/config.json (listen :${HY_LISTEN_PORT})"
echo "  -> default obfs password is 'changeme-obfs' — change it from the panel's Server Config page."
echo "Users file:              ${HY_DIR}/users.json  (managed via the panel, don't hand-edit while services run)"
echo
systemctl status hysteria-server.service --no-pager
systemctl status badvpn7300.service --no-pager
systemctl status hysteria-auth.service --no-pager
systemctl status hysteria-panel.service --no-pager
