const express=require("express"),fs=require("fs"),path=require("path"),crypto=require("crypto"),{execFile,spawn}=require("child_process"),si=require("systeminformation");
const app=express();app.disable("x-powered-by");app.use(express.json({limit:"32kb"}));
const APP=__dirname,CFG=process.env.PANEL_CONFIG||"/etc/hysteria-panel/panel.json",USERSFILE=process.env.USERS_FILE||"/etc/hysteria/users.json",HYCFG="/etc/hysteria/config.json",PORT=Number(process.env.PANEL_PORT||2050),sessions=new Map(),attempts=new Map();
const SVC_HYSTERIA="hysteria-server",SVC_BADVPN="badvpn7300";
const run=(c,a=[],t=8000)=>new Promise((ok,no)=>execFile(c,a,{timeout:t,maxBuffer:524288},(e,o,s)=>e?no(Error((s||o||e.message).trim())):ok((o||"").trim())));
function cfg(){return JSON.parse(fs.readFileSync(CFG,"utf8"))} function save(c){fs.writeFileSync(CFG,JSON.stringify(c,null,2)+"\n",{mode:0o600})}
let ipCache={value:null,at:0};
async function publicIP(){if(ipCache.value&&Date.now()-ipCache.at<6e5)return ipCache.value;try{const v=await run("curl",["-s","--max-time","4","https://api.ipify.org"]);if(v&&/^[\d.:a-fA-F]+$/.test(v)){ipCache={value:v,at:Date.now()};return v}}catch{}return null}

// --- Users store (users.json) -------------------------------------------
// Each user: { name, password, auth_str, days, expiresAt, limit, enabled, createdAt }
// auth_str is always `${name}:${password}` — kept as its own field so the
// Hysteria auth server can match it directly against what the client sends.
function loadUsers(){if(!fs.existsSync(USERSFILE))return[];try{const d=JSON.parse(fs.readFileSync(USERSFILE,"utf8"));return d.users||[]}catch{return[]}}
function saveUsers(list){fs.mkdirSync(path.dirname(USERSFILE),{recursive:true});fs.writeFileSync(USERSFILE,JSON.stringify({users:list},null,2)+"\n",{mode:0o600})}
function isExpired(u){return u.expiresAt?new Date(u.expiresAt)<new Date():false}
const safeName=u=>typeof u==="string"&&/^[a-zA-Z0-9_-]{4,12}$/.test(u);
const safePass=p=>typeof p==="string"&&/^[a-zA-Z0-9]{4,12}$/.test(p);

// --- Online-session tracker ----------------------------------------------
// Hysteria itself doesn't log connect/disconnect the way udp-custom did, so
// session presence here is tracked via the auth server: every time a client
// authenticates, the auth server (auth-server.js) records a heartbeat in
// /etc/hysteria/sessions.json (name -> [{src, lastSeen}]). We just read it.
const SESSIONSFILE=process.env.SESSIONS_FILE||"/etc/hysteria/sessions.json";
const SESSION_TIMEOUT_MS=90*1000; // treat a src as gone if no heartbeat in 90s
function loadSessions(){if(!fs.existsSync(SESSIONSFILE))return{};try{return JSON.parse(fs.readFileSync(SESSIONSFILE,"utf8"))}catch{return{}}}
function onlineInfo(name){const all=loadSessions();const list=all[name]||[];const now=Date.now();const active=list.filter(s=>now-s.lastSeen<SESSION_TIMEOUT_MS);return{online:active.length>0,sessions:active.length}}
function allOnline(){const all=loadSessions();const now=Date.now();const out=[];for(const[name,list]of Object.entries(all)){const active=list.filter(s=>now-s.lastSeen<SESSION_TIMEOUT_MS);if(active.length)out.push({username:name,sessions:active.length})}return out}

function hp(p,s){return crypto.scryptSync(p,s,64)} function valid(p,c){if(typeof p!=="string")return false;const a=hp(p,c.passwordSalt),b=Buffer.from(c.passwordHash,"hex");return a.length===b.length&&crypto.timingSafeEqual(a,b)}
function ip(req){return String(req.headers["x-forwarded-for"]||req.socket.remoteAddress||"").split(",")[0].trim()}
function limited(x){let a=attempts.get(x),n=Date.now();if(!a||n-a.first>9e5){a={first:n,count:0,until:0};attempts.set(x,a)}return a.until>n}
function fail(x){let a=attempts.get(x)||{first:Date.now(),count:0,until:0};a.count++;if(a.count>=8)a.until=Date.now()+9e5;attempts.set(x,a)}
function auth(req,res,next){const t=req.headers.authorization?.replace(/^Bearer\s+/i,"");const s=t&&sessions.get(t);if(!s)return res.status(401).json({error:"Unauthorized"});if(Date.now()-s.created>432e5){sessions.delete(t);return res.status(401).json({error:"Session expired"})}req.session=s;next()}
async function svc(n){try{const state=await run("systemctl",["is-active",n]),enabled=await run("systemctl",["is-enabled",n]).catch(()=>"disabled");return{active:state==="active",state,enabled}}catch{return{active:false,state:"unknown",enabled:"unknown"}}}

app.use((q,r,n)=>{r.setHeader("X-Content-Type-Options","nosniff");r.setHeader("X-Frame-Options","DENY");r.setHeader("Referrer-Policy","no-referrer");n()});

app.post("/api/login",(q,r)=>{const x=ip(q);if(limited(x))return r.status(429).json({error:"Too many login attempts. Try again in 15 minutes."});const c=cfg();if(!valid(q.body?.password,c)||q.body?.username!==c.user){fail(x);return r.status(401).json({error:"Invalid username or password"})}attempts.delete(x);const t=crypto.randomBytes(32).toString("hex");sessions.set(t,{user:c.user,created:Date.now(),ip:x});r.json({token:t})});
app.post("/api/logout",auth,(q,r)=>{sessions.delete(q.headers.authorization.replace(/^Bearer\s+/i,""));r.json({ok:true})});
app.post("/api/account/password",auth,(q,r)=>{try{const c=cfg(),{currentPassword,newPassword}=q.body||{};if(!valid(currentPassword,c))return r.status(400).json({error:"Current password is incorrect"});if(typeof newPassword!=="string"||!/^[a-zA-Z0-9!@#$%^&*_.-]{8,64}$/.test(newPassword))return r.status(400).json({error:"New password must be 8-64 allowed characters"});const s=crypto.randomBytes(16).toString("hex");c.passwordSalt=s;c.passwordHash=hp(newPassword,s).toString("hex");save(c);sessions.clear();r.json({ok:true})}catch(e){r.status(500).json({error:e.message})}});

app.get("/api/overview",auth,async(q,r)=>{try{const[a,m,f,n,o,t,hy,gw,detectedIP]=await Promise.all([si.currentLoad(),si.mem(),si.fsSize(),si.networkStats(),si.osInfo(),si.time(),svc(SVC_HYSTERIA),svc(SVC_BADVPN),publicIP()]);const d=f.find(x=>x.mount==="/")||f[0]||{},av=Number(m.available||m.total-m.used),kb=x=>Math.round(x||0);let listenPort=null;try{listenPort=Number(String(JSON.parse(fs.readFileSync(HYCFG,"utf8")).listen||"").replace(":",""))||null}catch{}const c=cfg(),panelHost=c.panelHost||"";const online=allOnline();r.json({cpu:+a.currentLoad.toFixed(1),cpuCores:o.cpus||require("os").cpus().length,ram:+(((m.total-av)/m.total)*100).toFixed(1),ramUsed:kb(m.total-av),ramAvailable:kb(av),ramTotal:kb(m.total),disk:+(d.use||0).toFixed(1),diskUsed:kb(d.used),diskTotal:kb(d.size),rx:n.reduce((x,y)=>x+(y.rx_sec||0),0),tx:n.reduce((x,y)=>x+(y.tx_sec||0),0),uptime:t.uptime,hostname:o.hostname,platform:o.platform,arch:o.arch,hysteria:hy,badvpn:gw,activeSessions:online.reduce((a,x)=>a+x.sessions,0),listenPort,detectedIP,panelHost,connectHost:panelHost||detectedIP||o.hostname})}catch(e){r.status(500).json({error:e.message})}});
app.put("/api/settings/host",auth,(q,r)=>{try{const h=String(q.body?.panelHost||"").trim();if(h&&!/^[a-zA-Z0-9.\-:]{1,253}$/.test(h))return r.status(400).json({error:"Invalid host/domain format"});const c=cfg();c.panelHost=h;save(c);r.json({ok:true,panelHost:h})}catch(e){r.status(500).json({error:e.message})}});

app.get("/api/config",auth,(q,r)=>{try{const c=JSON.parse(fs.readFileSync(HYCFG,"utf8"));r.json({listen:c.listen,obfs:c.obfs||"",up_mbps:c.up_mbps||0,down_mbps:c.down_mbps||0})}catch(e){r.status(500).json({error:e.message})}});
app.put("/api/config",auth,async(q,r)=>{try{const x=q.body||{},p=Number(String(x.listen||"").replace(":","")),up=Number(x.up_mbps),down=Number(x.down_mbps);if(!Number.isInteger(p)||p<1||p>65535||!Number.isInteger(up)||up<1||!Number.isInteger(down)||down<1)return r.status(400).json({error:"Invalid port or bandwidth values"});const c=JSON.parse(fs.readFileSync(HYCFG,"utf8"));c.listen=":"+p;c.up_mbps=up;c.down_mbps=down;if(typeof x.obfs==="string")c.obfs=x.obfs;fs.copyFileSync(HYCFG,HYCFG+".bak");fs.writeFileSync(HYCFG,JSON.stringify(c,null,2)+"\n",{mode:0o600});await run("systemctl",["restart",SVC_HYSTERIA]);r.json({ok:true,status:await svc(SVC_HYSTERIA)})}catch(e){r.status(500).json({error:e.message})}});

app.post("/api/service/:name/:action",auth,async(q,r)=>{const n={hysteria:SVC_HYSTERIA,badvpn:SVC_BADVPN}[q.params.name],a=q.params.action;if(!n||!["start","stop","restart"].includes(a))return r.status(400).json({error:"Invalid service/action"});try{await run("systemctl",[a,n]);r.json({ok:true,status:await svc(n)})}catch(e){r.status(500).json({error:e.message})}});
app.get("/api/logs/:name",auth,async(q,r)=>{const n={hysteria:SVC_HYSTERIA,badvpn:SVC_BADVPN,panel:"hysteria-panel",authserver:"hysteria-auth"}[q.params.name];if(!n)return r.status(400).json({error:"Invalid log target"});try{r.json({log:await run("journalctl",["-u",n,"-n","200","--no-pager","-o","short-iso"],1e4)})}catch(e){r.status(500).json({error:e.message})}});
app.get("/api/online",auth,(q,r)=>{const list=allOnline();r.json({online:list,totalUsers:list.length,totalSessions:list.reduce((a,x)=>a+x.sessions,0)})});

app.get("/api/users",auth,(q,r)=>{const list=loadUsers().map(u=>({...u,...onlineInfo(u.name),expired:isExpired(u),days:u.expiresAt?Math.max(0,Math.ceil((new Date(u.expiresAt)-Date.now())/864e5)):null}));r.json({users:list})});
app.post("/api/users",auth,(q,r)=>{const{name,password,days,limit}=q.body||{},d=Number(days),l=Number(limit);if(!safeName(name)||!safePass(password))return r.status(400).json({error:"Username 4-12 (A-Z a-z 0-9 _ -), password 4-12 alphanumeric"});if(!Number.isInteger(d)||d<1||d>360||!Number.isInteger(l)||l<1||l>999)return r.status(400).json({error:"Days 1-360 and device limit 1-999"});const list=loadUsers();if(list.some(u=>u.name===name))return r.status(409).json({error:"User already exists"});const now=new Date();const expiresAt=new Date(now.getTime()+d*864e5).toISOString();const user={name,password,auth_str:`${name}:${password}`,limit:l,expiresAt,enabled:true,createdAt:now.toISOString()};list.push(user);saveUsers(list);r.json({ok:true,user:{...user,...onlineInfo(name),expired:false,days:d}})});
app.post("/api/users/:name/:action",auth,async(q,r)=>{const name=q.params.name,a=q.params.action;const list=loadUsers();const idx=list.findIndex(u=>u.name===name);if(idx===-1)return r.status(404).json({error:"User not found"});try{if(a==="delete"){list.splice(idx,1);saveUsers(list)}else if(a==="block"){list[idx].enabled=false;saveUsers(list)}else if(a==="unblock"){list[idx].enabled=true;saveUsers(list)}else if(a==="renew"){const d=Number(q.body?.days);if(!Number.isInteger(d)||d<1||d>360)return r.status(400).json({error:"Days 1-360"});list[idx].expiresAt=new Date(Date.now()+d*864e5).toISOString();saveUsers(list)}else return r.status(400).json({error:"Invalid action"});const u=loadUsers().find(x=>x.name===name);r.json({ok:true,user:u?{...u,...onlineInfo(name),expired:isExpired(u),days:u.expiresAt?Math.max(0,Math.ceil((new Date(u.expiresAt)-Date.now())/864e5)):null}:null})}catch(e){r.status(500).json({error:e.message})}});

app.post("/api/reboot",auth,(q,r)=>{r.json({ok:true,message:"Reboot scheduled"});setTimeout(()=>run("systemctl",["reboot"]).catch(()=>{}),800)});

app.use(express.static(path.join(APP,"public")));
app.get(/.*/,(q,r)=>r.sendFile(path.join(APP,"public","index.html")));
app.listen(PORT,"0.0.0.0",()=>console.log(`Hysteria Panel listening on :${PORT}`));
