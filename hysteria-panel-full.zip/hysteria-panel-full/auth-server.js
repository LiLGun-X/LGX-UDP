// Hysteria 1 external HTTP auth server.
//
// Hysteria 1's "external" auth mode POSTs, on each client connection, JSON
// shaped like:
//   {"addr": "1.2.3.4:5678", "payload": "<base64 of auth_str>", "send": N, "recv": N}
// to this endpoint and expects HTTP 200 with {"ok": bool, "msg": "..."}.
//
// Beyond plain match-or-not, this also enforces:
//   - enabled flag (blocked users are rejected)
//   - expiry (expired users are rejected)
//   - device limit: if a user is already at their session limit and a NEW
//     addr connects, the OLDEST tracked session for that user is evicted
//     (removed from sessions.json) and the new one takes its place. Hysteria
//     itself doesn't forcibly disconnect the old socket from here - eviction
//     just means the old session stops being renewed/counted, so the panel's
//     "online" count reflects the swap. (Hysteria will naturally drop the
//     old connection on its own idle timeout once no traffic flows for it,
//     since nothing is heartbeating it anymore.)
//
// Sessions are heartbeated on every auth call: each connecting addr refreshes
// its lastSeen timestamp, and stale entries (no heartbeat in SESSION_TIMEOUT_MS)
// are pruned so the device count reflects reality even without explicit
// disconnect events (Hysteria 1 doesn't log those in a structured way).

const fs = require("fs");
const http = require("http");
const path = require("path");

const USERSFILE = process.env.USERS_FILE || "/etc/hysteria/users.json";
const SESSIONSFILE = process.env.SESSIONS_FILE || "/etc/hysteria/sessions.json";
const PORT = Number(process.env.AUTH_PORT || 9091);
const SESSION_TIMEOUT_MS = 90 * 1000;

function loadUsers() {
  try {
    return JSON.parse(fs.readFileSync(USERSFILE, "utf8")).users || [];
  } catch {
    return [];
  }
}

function loadSessions() {
  try {
    return JSON.parse(fs.readFileSync(SESSIONSFILE, "utf8"));
  } catch {
    return {};
  }
}

function saveSessions(data) {
  fs.mkdirSync(path.dirname(SESSIONSFILE), { recursive: true });
  fs.writeFileSync(SESSIONSFILE, JSON.stringify(data, null, 2), { mode: 0o600 });
}

function pruneStale(list, now) {
  return list.filter((s) => now - s.lastSeen < SESSION_TIMEOUT_MS);
}

// Returns {ok, msg}. Mutates sessions.json as a side effect for accepted auths.
function evaluate(authStr, addr) {
  if (!authStr) return { ok: false, msg: "empty credential" };

  const users = loadUsers();
  const user = users.find((u) => u.auth_str === authStr);
  if (!user) return { ok: false, msg: "unknown user" };
  if (!user.enabled) return { ok: false, msg: "user disabled" };
  if (user.expiresAt && new Date(user.expiresAt) < new Date()) {
    return { ok: false, msg: "user expired" };
  }

  const limit = Number(user.limit) || 1;
  const now = Date.now();
  const sessions = loadSessions();
  let list = pruneStale(sessions[user.name] || [], now);

  const already = list.find((s) => s.src === addr);
  if (already) {
    already.lastSeen = now; // heartbeat existing session
  } else {
    if (list.length >= limit) {
      // kick oldest (FIFO) to make room for the new device
      list.sort((a, b) => a.lastSeen - b.lastSeen);
      list.shift();
    }
    list.push({ src: addr, lastSeen: now });
  }

  sessions[user.name] = list;
  saveSessions(sessions);

  return { ok: true, msg: "ok" };
}

const server = http.createServer((req, res) => {
  if (req.method !== "POST" || req.url !== "/verify") {
    res.writeHead(404);
    res.end();
    return;
  }

  let body = "";
  req.on("data", (chunk) => (body += chunk));
  req.on("end", () => {
    let payload = {};
    try {
      payload = JSON.parse(body || "{}");
    } catch {
      // ignore malformed body, treated as empty below
    }

    let authStr = "";
    try {
      authStr = Buffer.from(payload.payload || "", "base64").toString("utf8");
    } catch {
      authStr = "";
    }

    const result = evaluate(authStr, payload.addr || "");
    const out = JSON.stringify(result);
    res.writeHead(200, { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(out) });
    res.end(out);
  });
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`Hysteria auth server listening on 127.0.0.1:${PORT}`);
});
