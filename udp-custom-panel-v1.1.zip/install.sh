#!/usr/bin/env bash
set -euo pipefail

# UDP CUSTOM PANEL v1.0
# Modern mobile-first control panel for http-custom/udp-custom
# Ubuntu 20.04+ x86_64

APP_DIR="/opt/udp-custom-panel"
CFG_DIR="/etc/udp-custom-panel"
SERVICE="/etc/systemd/system/udp-custom-panel.service"
PORT="${PANEL_PORT:-2050}"

if [[ $EUID -ne 0 ]]; then
  echo "Run as root: sudo bash install.sh"
  exit 1
fi

echo "== UDP CUSTOM PANEL v1.0 =="

if ! command -v node >/dev/null 2>&1 || ! node -e 'process.exit(Number(process.versions.node.split(".")[0]) < 18)' 2>/dev/null; then
  echo "[1/6] Installing Node.js 20..."
  apt-get update -y
  apt-get install -y curl ca-certificates
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
else
  echo "[1/6] Node.js already installed: $(node -v)"
fi

echo "[2/6] Installing panel files..."
rm -rf "$APP_DIR"
mkdir -p "$APP_DIR/public"
cp -a ./* "$APP_DIR/"
rm -f "$APP_DIR/install.sh"
chown -R root:root "$APP_DIR"

echo "[3/6] Installing dependencies..."
cd "$APP_DIR"
npm install --omit=dev

echo "[4/6] Creating secure panel configuration..."
mkdir -p "$CFG_DIR"
chmod 700 "$CFG_DIR"

ADMIN_USER="${PANEL_USER:-admin}"
ADMIN_PASS="${PANEL_PASS:-gunx}"

node - "$CFG_DIR/panel.json" "$ADMIN_USER" "$ADMIN_PASS" "$PORT" <<'NODE'
const fs = require('fs');
const crypto = require('crypto');
const [,, file, user, pass, port] = process.argv;
const salt = crypto.randomBytes(16).toString('hex');
const hash = crypto.scryptSync(pass, salt, 64).toString('hex');
const cfg = {
  port: Number(port),
  user,
  passwordHash: hash,
  passwordSalt: salt,
  createdAt: new Date().toISOString()
};
fs.writeFileSync(file, JSON.stringify(cfg, null, 2) + "\n", {mode:0o600});
NODE
chmod 600 "$CFG_DIR/panel.json"

echo "[5/6] Creating systemd service..."
cat > "$SERVICE" <<EOF
[Unit]
Description=UDP Custom Web Panel
After=network.target udp-custom.service udpgw.service
Wants=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$APP_DIR
Environment=NODE_ENV=production
Environment=PANEL_CONFIG=$CFG_DIR/panel.json
Environment=PANEL_PORT=$PORT
ExecStart=/usr/bin/node $APP_DIR/server.js
Restart=always
RestartSec=3
NoNewPrivileges=false
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable udp-custom-panel >/dev/null
systemctl restart udp-custom-panel

echo "[6/6] Checking service..."
sleep 1
if systemctl is-active --quiet udp-custom-panel; then
  IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
  echo
  echo "=============================================="
  echo " UDP CUSTOM PANEL INSTALLED"
  echo "=============================================="
  echo " URL      : http://${IP:-YOUR_VPS_IP}:$PORT"
  echo " Username : $ADMIN_USER"
  echo " Password : $ADMIN_PASS"
  echo "----------------------------------------------"
  echo "Service  : systemctl status udp-custom-panel"
  echo "Logs     : journalctl -u udp-custom-panel -f"
  echo "=============================================="
  echo
else
  echo "Panel failed to start."
  journalctl -u udp-custom-panel --no-pager -n 80
  exit 1
fi
