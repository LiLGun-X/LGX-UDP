# UDP Custom Panel v1.0

Modern mobile-first web panel for `http-custom/udp-custom`.

## Install

```bash
unzip udp-custom-panel.zip
cd udp-custom-panel
chmod +x install.sh
sudo ./install.sh
```

Optional:
```bash
PANEL_PORT=8080 PANEL_USER=admin PANEL_PASS='YourStrongPassword' sudo -E ./install.sh
```

The installer creates:
- `/opt/udp-custom-panel`
- `/etc/udp-custom-panel/panel.json`
- `udp-custom-panel.service`

It controls the existing `udp-custom` and `udpgw` systemd services and edits `/root/udp/config.json` with a backup.

## Security

The backend exposes only allowlisted service/config/user operations; it does not provide an arbitrary shell terminal. Put the panel behind HTTPS or a private VPN for production.


## Default login
- Panel port: `2050`
- Username: `admin`
- Password: `gunx`

Change the panel password from **Settings → Change Password** after login.
