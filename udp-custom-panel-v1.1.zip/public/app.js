let token=localStorage.getItem("udp_panel_token");
const $=id=>document.getElementById(id);
function toast(msg,ok=true){const x=document.createElement("div");x.className="toast "+(ok?"ok":"err");x.textContent=msg;document.body.appendChild(x);setTimeout(()=>x.remove(),2500)}
async function api(url,opt={}){opt.headers={...(opt.headers||{}),Authorization:"Bearer "+token,"Content-Type":"application/json"};let r=await fetch(url,opt);if(r.status===401){logout(true);throw Error("Unauthorized")}let d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||"Request failed");return d}
function logout(silent=false){localStorage.removeItem("udp_panel_token");token=null;$("app").classList.add("hidden");$("login").classList.remove("hidden");if(!silent)toast("Logged out")}
$("loginForm").onsubmit=async e=>{e.preventDefault();$("loginErr").textContent="";try{let d=await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:$("username").value,password:$("password").value})});let j=await d.json();if(!d.ok)throw Error(j.error);token=j.token;localStorage.setItem("udp_panel_token",token);showApp()}catch(x){$("loginErr").textContent=x.message}}
$("logout").onclick=()=>logout();
$("passwordForm").onsubmit=async e=>{
  e.preventDefault();
  if($("newPassword").value!==$("confirmPassword").value){toast("Passwords do not match",false);return}
  try{
    await api("/api/account/password",{method:"POST",body:JSON.stringify({currentPassword:$("currentPassword").value,newPassword:$("newPassword").value})});
    localStorage.removeItem("udp_panel_token"); token=null;
    $("app").classList.add("hidden"); $("login").classList.remove("hidden");
    $("passwordForm").reset();
    toast("Password changed. Please sign in again");
  }catch(x){toast(x.message,false)}
}

function showApp(){$("login").classList.add("hidden");$("app").classList.remove("hidden");refresh();loadConfig();loadUsers()}
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>page(b.dataset.page));
function page(p){document.querySelectorAll(".page").forEach(x=>x.classList.add("hidden"));$(p).classList.remove("hidden");document.querySelectorAll("nav button").forEach(x=>x.classList.toggle("active",x.dataset.page===p));$("pageTitle").textContent=p==="udp"?"UDP Custom":p[0].toUpperCase()+p.slice(1);if(p==="users")loadUsers();if(p==="logs")loadLogs();if(p==="vps")refresh()}
$("menu").onclick=()=>toast("On small screens use the desktop layout or browser menu");
async function refresh(){try{let d=await api("/api/overview");$("hostname").textContent=d.hostname;$("platform").textContent=d.platform+" • "+d.arch;$("cpu").textContent=d.cpu+"%";$("ram").textContent=d.ram+"%";$("disk").textContent=d.disk+"%";$("connections").textContent=d.connections;$("cpuBar").style.width=d.cpu+"%";$("ramBar").style.width=d.ram+"%";$("diskBar").style.width=d.disk+"%";$("udpState").textContent=d.udpCustom.active?"RUNNING":"STOPPED";$("udpState").classList.toggle("off",!d.udpCustom.active);$("gwState").textContent=d.udpgw.active?"RUNNING":"STOPPED";$("gwState").classList.toggle("off",!d.udpgw.active);$("rx").textContent=fmt(d.rx)+"/s";$("tx").textContent=fmt(d.tx)+"/s";$("uptime").textContent=dur(d.uptime);$("vHost").textContent=d.hostname;$("vPlatform").textContent=d.platform;$("vArch").textContent=d.arch}catch(e){}}
function fmt(n){if(!n)return"0 B";let u=["B","KB","MB","GB"];let i=0;while(n>=1024&&i<3){n/=1024;i++}return n.toFixed(i?1:0)+" "+u[i]}
function dur(s){let d=Math.floor(s/86400);s%=86400;let h=Math.floor(s/3600);s%=3600;let m=Math.floor(s/60);return `${d}d ${h}h ${m}m`}
async function service(n,a){try{await api(`/api/service/${n}/${a}`,{method:"POST"});toast(a+" successful");refresh()}catch(e){toast(e.message,false)}}
async function loadConfig(){try{let d=await api("/api/config");$("listenPort").value=String(d.listen).replace(":","");$("streamBuffer").value=d.stream_buffer;$("receiveBuffer").value=d.receive_buffer}catch(e){}}
async function saveConfig(){try{await api("/api/config",{method:"PUT",body:JSON.stringify({listen:":"+$("listenPort").value,stream_buffer:Number($("streamBuffer").value),receive_buffer:Number($("receiveBuffer").value)})});toast("Saved & UDP-CUSTOM restarted");refresh()}catch(e){toast(e.message,false)}}
async function loadUsers(){try{let d=await api("/api/users");$("usersBody").innerHTML=d.users.map(u=>`<tr><td><b>${esc(u.username)}</b></td><td>${esc(u.password||"—")}</td><td>${u.days===null?"—":u.days}</td><td>${u.limit}</td><td><span class="pill ${u.blocked?"bad":""}">${u.blocked?"BLOCKED":"ACTIVE"}</span></td><td><button onclick="userAction('${esc(u.username)}','${u.blocked?"unblock":"block"}')">${u.blocked?"Unblock":"Block"}</button> <button onclick="renew('${esc(u.username)}')">Renew</button> <button class="danger" onclick="userAction('${esc(u.username)}','delete')">Delete</button></td></tr>`).join("")||`<tr><td colspan="6">No users</td></tr>`}catch(e){toast(e.message,false)}}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function openUser(){$("modal").classList.remove("hidden")}
function closeModal(){$("modal").classList.add("hidden")}
$("userForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/users",{method:"POST",body:JSON.stringify({username:$("uName").value,password:$("uPass").value,days:Number($("uDays").value),limit:Number($("uLimit").value)})});closeModal();e.target.reset();toast("User created");loadUsers()}catch(x){toast(x.message,false)}}
async function userAction(u,a){if(a==="delete"&&!confirm("Delete "+u+"?"))return;try{await api(`/api/users/${encodeURIComponent(u)}/${a}`,{method:"POST"});toast(a+" successful");loadUsers()}catch(e){toast(e.message,false)}}
async function renew(u){let d=prompt("Renew for how many days?","30");if(!d)return;try{await api(`/api/users/${encodeURIComponent(u)}/renew`,{method:"POST",body:JSON.stringify({days:Number(d)})});toast("User renewed");loadUsers()}catch(e){toast(e.message,false)}}
async function loadLogs(){try{let d=await api("/api/logs/"+$("logSelect").value);$("logBox").textContent=d.log||"No logs";$("logBox").scrollTop=$("logBox").scrollHeight}catch(e){$("logBox").textContent=e.message}}
async function rebootVPS(){if(!confirm("Reboot VPS now?"))return;try{await api("/api/reboot",{method:"POST"});toast("Reboot scheduled")}catch(e){toast(e.message,false)}}
if(token)showApp();
setInterval(()=>{if(token&&!$("app").classList.contains("hidden"))refresh()},5000);
