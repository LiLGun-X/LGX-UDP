const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { execFile } = require("child_process");
const si = require("systeminformation");

const app = express();
app.use(express.json({limit: "32kb"}));

const APP_DIR = __dirname;
const CFG = process.env.PANEL_CONFIG || "/etc/udp-custom-panel/panel.json";
const PORT = Number(process.env.PANEL_PORT || 8080);
const sessions = new Map();

function loadCfg() {
  return JSON.parse(fs.readFileSync(CFG, "utf8"));
}
function saveCfg(c) {
  fs.writeFileSync(CFG, JSON.stringify(c, null, 2) + "\n", {mode:0o600});
}
function hashPassword(pass, salt) {
  return crypto.scryptSync(pass, salt, 64);
}
function validPassword(pass, c) {
  if (typeof pass !== "string") return false;
  const got = hashPassword(pass, c.passwordSalt);
  const expected = Buffer.from(c.passwordHash, "hex");
  return got.length === expected.length && crypto.timingSafeEqual(got, expected);
}
function auth(req,res,next) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i,"");
  if (!token || !sessions.has(token)) return res.status(401).json({error:"Unauthorized"});
  const s = sessions.get(token);
  if (Date.now() - s.created > 12*60*60*1000) {
    sessions.delete(token);
    return res.status(401).json({error:"Session expired"});
  }
  req.session = s;
  next();
}
function run(cmd,args=[],timeout=8000) {
  return new Promise((resolve,reject)=>{
    execFile(cmd,args,{timeout,maxBuffer:512*1024},(err,stdout,stderr)=>{
      if(err) return reject(new Error((stderr||stdout||err.message).trim()));
      resolve((stdout||"").trim());
    });
  });
}
async function serviceStatus(name) {
  try {
    const state = await run("systemctl",["is-active",name]);
    const enabled = await run("systemctl",["is-enabled",name]).catch(()=> "disabled");
    return {active: state==="active", state, enabled};
  } catch {
    return {active:false,state:"unknown",enabled:"unknown"};
  }
}
function safeUser(u) {
  return typeof u==="string" && /^[a-zA-Z0-9_-]{4,12}$/.test(u);
}
function udpUsers() {
  let txt="";
  try { txt=fs.readFileSync("/etc/passwd","utf8"); } catch { return []; }
  return txt.split("\n").map(line=>{
    const p=line.split(":");
    if(p.length<7 || p[5] !== "/home/"+p[0] || p[6] !== "/bin/false") return null;
    if(["syslog","hwid","token"].some(x=>p[0].includes(x))) return null;
    const gecos=p[4]||"";
    const parts=gecos.split(",");
    const limit=parts[0] || "";
    const pass=parts[1] || "";
    let exp="";
    try { exp=String(require("child_process").execFileSync("chage",["-l",p[0]],{encoding:"utf8"}).split("\n").find(x=>x.startsWith("Account expires"))?.split(": ").slice(1).join(": ")||""); } catch {}
    let days=null;
    if(exp && exp!=="never") {
      const d=new Date(exp);
      if(!Number.isNaN(d.getTime())) days=Math.max(0,Math.ceil((d-Date.now())/86400000));
    }
    let locked=false;
    try { locked=require("child_process").execFileSync("passwd",["--status",p[0]],{encoding:"utf8"}).split(/\s+/)[1] !== "P"; } catch {}
    return {username:p[0],password:pass,limit:Number(limit)||0,expires:exp,days,blocked:locked};
  }).filter(Boolean);
}

app.post("/api/login",(req,res)=>{
  const c=loadCfg();
  if(!validPassword(req.body?.password,c) || req.body?.username!==c.user) return res.status(401).json({error:"Invalid username or password"});
  const token=crypto.randomBytes(32).toString("hex");
  sessions.set(token,{user:c.user,created:Date.now()});
  res.json({token});
});
app.post("/api/account/password",auth,(req,res)=>{
  try {
    const {currentPassword,newPassword} = req.body || {};
    const c = loadCfg();
    if (!validPassword(currentPassword,c)) return res.status(400).json({error:"Current password is incorrect"});
    if (typeof newPassword !== "string" || newPassword.length < 4 || newPassword.length > 64)
      return res.status(400).json({error:"New password must be 4-64 characters"});
    const salt = crypto.randomBytes(16).toString("hex");
    c.passwordSalt = salt;
    c.passwordHash = hashPassword(newPassword,salt).toString("hex");
    saveCfg(c);
    sessions.clear();
    res.json({ok:true});
  } catch(e) { res.status(500).json({error:e.message}); }
});
app.post("/api/logout",auth,(req,res)=>{
  const token=req.headers.authorization.replace(/^Bearer\s+/i,"");
  sessions.delete(token); res.json({ok:true});
});

app.get("/api/overview",auth,async(req,res)=>{
  try {
    const [load,mem,fsz,net,os,up,udp,gw] = await Promise.all([
      si.currentLoad(),si.mem(),si.fsSize(),si.networkStats(),si.osInfo(),si.time(),serviceStatus("udp-custom"),serviceStatus("udpgw")
    ]);
    const disk=fsz.find(x=>x.mount==="/")||fsz[0]||{};
    const n=net.reduce((a,x)=>({rx:a.rx+x.rx_sec,tx:a.tx+x.tx_sec}),{rx:0,tx:0});
    const conns=await run("ss",["-uan"]).catch(()=> "");
    res.json({
      cpu:Number(load.currentLoad.toFixed(1)),
      ram:Number(((mem.used/mem.total)*100).toFixed(1)),
      ramUsed:mem.used,ramTotal:mem.total,
      disk:Number((disk.use||0).toFixed(1)),
      diskUsed:disk.used||0,diskTotal:disk.size||0,
      rx:n.rx||0,tx:n.tx||0,
      uptime:up.uptime,hostname:os.hostname,platform:os.platform,arch:os.arch,
      udpCustom:udp,udpgw:gw,
      connections:Math.max(0,conns.split("\n").filter(Boolean).length-1)
    });
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.get("/api/config",auth,(req,res)=>{
  try {
    const c=JSON.parse(fs.readFileSync("/root/udp/config.json","utf8"));
    res.json(c);
  } catch(e){res.status(500).json({error:e.message});}
});

app.put("/api/config",auth,async(req,res)=>{
  try {
    const incoming=req.body||{};
    if(typeof incoming.listen!=="string" || !/^:[0-9]{1,5}$/.test(incoming.listen)) return res.status(400).json({error:"Invalid listen port"});
    const port=Number(incoming.listen.slice(1));
    if(port<1||port>65535) return res.status(400).json({error:"Port must be 1-65535"});
    const cfg={
      listen:incoming.listen,
      stream_buffer:Number(incoming.stream_buffer)||33554432,
      receive_buffer:Number(incoming.receive_buffer)||83886080,
      auth:{mode:"passwords"}
    };
    fs.copyFileSync("/root/udp/config.json","/root/udp/config.json.bak");
    fs.writeFileSync("/root/udp/config.json",JSON.stringify(cfg,null,2)+"\n",{mode:0o600});
    await run("systemctl",["restart","udp-custom"]);
    res.json({ok:true,config:cfg});
  } catch(e){res.status(500).json({error:e.message});}
});

app.post("/api/service/:name/:action",auth,async(req,res)=>{
  const names={udp:"udp-custom",udpgw:"udpgw"};
  const actions=new Set(["start","stop","restart"]);
  const name=names[req.params.name], action=req.params.action;
  if(!name || !actions.has(action)) return res.status(400).json({error:"Invalid service/action"});
  try {
    await run("systemctl",[action,name]);
    res.json({ok:true,status:await serviceStatus(name)});
  } catch(e){res.status(500).json({error:e.message});}
});

app.get("/api/logs/:name",auth,async(req,res)=>{
  const names={udp:"udp-custom",udpgw:"udpgw",panel:"udp-custom-panel"};
  const name=names[req.params.name];
  if(!name) return res.status(400).json({error:"Invalid log target"});
  try {
    const out=await run("journalctl",["-u",name,"-n","200","--no-pager","-o","short-iso"],10000);
    res.json({log:out});
  } catch(e){res.status(500).json({error:e.message});}
});

app.get("/api/users",auth,(req,res)=>res.json({users:udpUsers()}));

app.post("/api/users",auth,async(req,res)=>{
  const {username,password,days,limit}=req.body||{};
  if(!safeUser(username) || typeof password!=="string" || !/^[a-zA-Z0-9_-]{4,12}$/.test(password))
    return res.status(400).json({error:"Username/password must be 4-12 alphanumeric characters"});
  const d=Number(days), l=Number(limit);
  if(!Number.isInteger(d)||d<1||d>360||!Number.isInteger(l)||l<1||l>999)
    return res.status(400).json({error:"Days 1-360 and connection limit 1-999"});
  if(udpUsers().some(x=>x.username===username)) return res.status(409).json({error:"User already exists"});
  try {
    const expires=new Date(Date.now()+d*86400000).toISOString().slice(0,10);
    await run("useradd",["-M","-s","/bin/false","-e",expires,"-K",`PASS_MAX_DAYS=${d}`,"-p",require("child_process").execFileSync("openssl",["passwd","-6",password],{encoding:"utf8"}).trim(),"-c",`${l},${password}`,username]);
    res.json({ok:true,user:udpUsers().find(x=>x.username===username)});
  } catch(e){res.status(500).json({error:e.message});}
});

app.post("/api/users/:u/:action",auth,async(req,res)=>{
  const u=req.params.u, a=req.params.action;
  if(!safeUser(u) || !udpUsers().some(x=>x.username===u)) return res.status(404).json({error:"User not found"});
  try {
    if(a==="delete") await run("userdel",["--force",u]);
    else if(a==="block") await run("usermod",["-L",u]);
    else if(a==="unblock") await run("usermod",["-U",u]);
    else if(a==="renew") {
      const d=Number(req.body?.days); if(!Number.isInteger(d)||d<1||d>360) return res.status(400).json({error:"Days 1-360"});
      const exp=new Date(Date.now()+d*86400000).toISOString().slice(0,10);
      await run("chage",["-E",exp,u]);
    } else return res.status(400).json({error:"Invalid action"});
    res.json({ok:true});
  } catch(e){res.status(500).json({error:e.message});}
});

app.post("/api/reboot",auth,async(req,res)=>{
  res.json({ok:true,message:"Reboot scheduled"});
  setTimeout(()=>run("systemctl",["reboot"]).catch(()=>{}),800);
});

app.use(express.static(path.join(APP_DIR,"public")));
app.get("*",(req,res)=>res.sendFile(path.join(APP_DIR,"public","index.html")));

app.listen(PORT,"0.0.0.0",()=>console.log(`UDP Custom Panel listening on :${PORT}`));
