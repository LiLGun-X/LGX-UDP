# UDP Custom Panel — v3.0

## What's new in this version
1. **Copy connection string per user** — Users page now has a "⧉ Copy" button on each row that copies `host:port@username:password` to the clipboard.
   - Host defaults to your server's public IP, auto-detected server-side (via `curl https://api.ipify.org`, cached for 10 minutes).
   - You can override it with a fixed domain in **Settings → Connection Host** (e.g. `sg1.jagoanip.my.id`) — leave blank to go back to auto-detect.
2. **Per-user online status — now implemented.** Your `udp-custom` binary does log connect/disconnect events with usernames (I initially missed this — the first log check happened before anyone had connected). The panel now tails `journalctl -u udp-custom -f` continuously in the background, parses lines like `[src:IP:PORT] [user:NAME] Client connected` / `... Client disconnected`, and tracks active sessions per user in memory.
   - Users page now has an **Online** column: 🟢 `Online (N)` where N is the number of active sessions (handles one user connected from multiple devices), or ⚪ `Offline`.
   - Updates automatically every 5 seconds while the Users page is open.
   - **Known limitations, stated plainly:**
     - State is in-memory only — if the panel process restarts, all tracked sessions reset to "offline" until the next connect/disconnect log line for that session appears.
     - Disconnect detection depends on `udp-custom`'s own timeout logging (~2 minutes in the sample I saw), so a dropped connection may show as "online" for a short while after it actually ends.
     - If `journalctl` can't read the `udp-custom` log for any reason (permissions, service not found), the tracker logs an error to the panel's own service log (`journalctl -u udp-custom-panel`) and retries every 3 seconds — check there if online status never changes from "Offline" for anyone who's actually connected.
3. **Port field clarified** — the Listen Port field now shows a note that it accepts 1–65535, and that this server only supports **one active UDP-Custom port at a time**.
   - I checked `/root/udp/config.json`: it has a single `"listen"` string, not an array. There's no multi-port support to expose — so a "primary/secondary port list" isn't something this build can show, because the underlying config doesn't have it.
4. **Dashboard restyled with circular gauges + service-monitor look**, matching the reference screenshots (kept your existing dark navy/purple palette rather than switching to the other panel's green — that panel is a different product with different services). `public/style.css` is a brand-new file — your new VPS (`xver-1ny5sx`) had none on disk, so nothing existing was overwritten.
   - CPU / RAM / Disk cards on the Dashboard are now circular percentage rings instead of flat bars, colored green/amber/red by threshold (< 70% / 70–90% / 90%+).
   - Service status cards (UDP-CUSTOM, UDPGW) got pill-style status badges matching the "Service Monitor" look from your reference image.
   - This is your actual two services (`udp-custom`, `udpgw`) — I did not add the other panel's six-service list (x-ui, SSH API, Dropbear, etc.) since none of those run on this server.

## Files
- `install.sh` — same as before (Node/npm clean reinstall + system-command check), now also copies the updated `server.js`/`app.js`/`index.html`.
- `server.js` — added: public-IP auto-detect, `panelHost` setting (persisted in the panel config file), `connectHost`/`listenPort`/`detectedIP`/`panelHost` fields in `/api/overview`, new `PUT /api/settings/host` endpoint, background `journalctl -f` tailer for online-session tracking, `GET /api/online` summary endpoint, `online`/`sessions` fields added to `GET /api/users`.
- `public/app.js` — added: copy-connection-string button + `copyConn()`, `saveHost()`, port hint text, host auto-detect hint text, Online column rendering + 5s auto-refresh while on the Users page.
- `public/index.html` — added: port hint paragraph under UDP Custom config, new "Connection Host" card in Settings, new "Online" column header in Users table.
- `public/style.css` — **new file**, built from scratch to match your reference screenshots (circular gauges, service-monitor cards) in the panel's existing navy/purple theme.

## Note on server change
This build targets your new VPS (`xver-1ny5sx`) — `install.sh` still writes to `/opt/udp-custom-panel` by default. If that's not the correct path on the new machine, edit `PANEL_DIR` near the top of `install.sh` before running it.

## Deploy
```bash
unzip UDP-panel-3.0.zip
cd UDP-panel-3.0
chmod +x install.sh
sudo bash install.sh
```
Safe to re-run on top of the v1 install — same idempotent script as before.

## After deploying
- Visit **Dashboard** once after logging in (loads the detected IP/host before the Users page needs it for the copy button).
- Check **Settings → Connection Host** — if it shows "Could not auto-detect server IP", your VPS may block outbound HTTPS to `api.ipify.org`; set the host manually there instead.
- The Users table "⧉ Copy" button uses the browser clipboard API when available (HTTPS/localhost), and automatically falls back to a manual-copy prompt on plain HTTP (your panel is currently on `http://84.160.243:2050`) — so it works either way, just with an extra click on HTTP.

