# UDP Custom Panel v2.0
For `http-custom/udp-custom`. Requires `/root/udp/udp-custom` and `/root/udp/config.json`.
Install as root with `chmod +x install.sh && ./install.sh`.
New install default: `admin / gunx` (change immediately).
User management follows upstream `module/udp`: Linux users, `/bin/false`, GECOS `LIMIT,PASSWORD`, `chage` expiry and `passwd` lock state.
Dashboard labels UDP sockets instead of pretending they are online users, and RAM uses MemAvailable-based pressure.
