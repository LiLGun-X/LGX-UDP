#!/bin/bash
set -e
APP=/opt/udp-custom-panel
CFG=/etc/udp-custom-panel/panel.json
SERVICE=/etc/systemd/system/udp-custom-panel.service
[ "$(id -u)" -eq 0 ] || { echo "Run as root."; exit 1; }
[ -x /root/udp/udp-custom ] && [ -f /root/udp/config.json ] || { echo "UDP-Custom is required at /root/udp first."; exit 1; }
apt-get update
apt-get install -y nodejs npm openssl
rm -rf "$APP"; mkdir -p "$APP"; cp -a . "$APP/"; cd "$APP"; npm install --omit=dev
mkdir -p /etc/udp-custom-panel
if [ ! -f "$CFG" ]; then
  SALT=$(openssl rand -hex 16)
  HASH=$(node -e 'const c=require("crypto");console.log(c.scryptSync(process.argv[1],process.argv[2],64).toString("hex"))' gunx "$SALT")
  printf '{
  "user":"admin",
  "passwordSalt":"%s",
  "passwordHash":"%s"
}
' "$SALT" "$HASH" > "$CFG"
  chmod 600 "$CFG"
  echo "New panel login: admin / gunx"
else chmod 600 "$CFG"; fi
cat > "$SERVICE" <<EOF
[Unit]
Description=UDP Custom Web Panel
After=network.target udp-custom.service
Wants=udp-custom.service
[Service]
Type=simple
User=root
WorkingDirectory=$APP
Environment=PANEL_PORT=2050
Environment=PANEL_CONFIG=$CFG
ExecStart=/usr/bin/node $APP/server.js
Restart=always
RestartSec=2
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now udp-custom-panel
echo "Panel: http://SERVER-IP:2050"
