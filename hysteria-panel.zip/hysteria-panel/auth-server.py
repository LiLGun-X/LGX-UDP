#!/usr/bin/env python3
"""
Hysteria 1 external HTTP auth server.

Hysteria 1's "external" auth mode POSTs, on each client connection, a JSON
body shaped like:
    {"addr": "1.2.3.4:5678", "payload": "<base64 of auth_str>", "send": N, "recv": N}
to the configured endpoint, and expects HTTP 200 with a JSON body like
{"ok": true, "msg": "..."}.

This tiny server reads /etc/hysteria/users.json (the same file the panel
edits) and answers those requests.

Runs on 127.0.0.1:9091 - only reachable locally, Hysteria calls it internally.

Server config.json should have:
  "auth": {
    "mode": "external",
    "config": {
      "http": "http://127.0.0.1:9091/verify"
    }
  }
"""

import base64
import json
from pathlib import Path
from http.server import BaseHTTPRequestHandler, HTTPServer

USERS_FILE = Path("/etc/hysteria/users.json")
PORT = 9091


def is_valid(auth_str):
    if not USERS_FILE.exists():
        return False
    try:
        with open(USERS_FILE, "r") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return False

    for user in data.get("users", []):
        if user.get("auth_str") == auth_str and user.get("enabled", True):
            return True
    return False


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # keep logs quiet; systemd journal will still capture stderr on crash

    def do_POST(self):
        if self.path != "/verify":
            self.send_response(404)
            self.end_headers()
            return

        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length else b"{}"

        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            payload = {}

        # "payload" is the client's auth_str, base64-encoded, per Hysteria 1 docs
        raw = payload.get("payload", "")
        try:
            auth_str = base64.b64decode(raw).decode("utf-8", errors="replace")
        except Exception:
            auth_str = ""

        ok = is_valid(auth_str)
        msg = "ok" if ok else "unknown user or disabled"

        response = json.dumps({"ok": ok, "msg": msg}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(response)))
        self.end_headers()
        self.wfile.write(response)


if __name__ == "__main__":
    server = HTTPServer(("127.0.0.1", PORT), Handler)
    print(f"Hysteria auth server listening on 127.0.0.1:{PORT}")
    server.serve_forever()
