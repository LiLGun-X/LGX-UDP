#!/usr/bin/env python3
"""
Hysteria 1 Management Panel
Simple Flask app to manage users and service status for a self-hosted Hysteria server.
"""

import json
import subprocess
import secrets
import string
from datetime import datetime
from functools import wraps
from pathlib import Path

from flask import Flask, render_template, request, jsonify, session, redirect, url_for

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)  # regenerated each restart -> logs out sessions, that's fine for a small panel

# ---- Configuration ----
USERS_FILE = Path("/etc/hysteria/users.json")
SERVICE_NAME = "hysteria-server.service"

# Panel login credentials - CHANGE THESE before deploying
PANEL_USERNAME = "admin"
PANEL_PASSWORD = "admin"  # change this before exposing the panel beyond localhost


# ---- Helpers ----

def load_users():
    if not USERS_FILE.exists():
        return []
    with open(USERS_FILE, "r") as f:
        data = json.load(f)
    return data.get("users", [])


def save_users(users):
    USERS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(USERS_FILE, "w") as f:
        json.dump({"users": users}, f, indent=2)


def generate_password(length=16):
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def run_systemctl(action):
    """Run a systemctl action on the hysteria service. Returns (ok, output)."""
    try:
        result = subprocess.run(
            ["systemctl", action, SERVICE_NAME],
            capture_output=True, text=True, timeout=15
        )
        return result.returncode == 0, (result.stdout + result.stderr).strip()
    except Exception as e:
        return False, str(e)


def get_service_status():
    try:
        result = subprocess.run(
            ["systemctl", "is-active", SERVICE_NAME],
            capture_output=True, text=True, timeout=10
        )
        return result.stdout.strip()
    except Exception:
        return "unknown"


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


# ---- Routes: auth ----

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if username == PANEL_USERNAME and password == PANEL_PASSWORD:
            session["logged_in"] = True
            return redirect(url_for("index"))
        error = "Wrong username or password."
    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---- Routes: pages ----

@app.route("/")
@login_required
def index():
    users = load_users()
    status = get_service_status()
    return render_template("index.html", users=users, status=status)


# ---- Routes: API ----

@app.route("/api/status")
@login_required
def api_status():
    return jsonify({"status": get_service_status()})


@app.route("/api/service/<action>", methods=["POST"])
@login_required
def api_service(action):
    if action not in ("start", "stop", "restart"):
        return jsonify({"ok": False, "error": "invalid action"}), 400
    ok, output = run_systemctl(action)
    return jsonify({"ok": ok, "output": output, "status": get_service_status()})


@app.route("/api/users", methods=["GET"])
@login_required
def api_users_list():
    return jsonify({"users": load_users()})


@app.route("/api/users", methods=["POST"])
@login_required
def api_users_add():
    data = request.get_json(force=True)
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"ok": False, "error": "Name is required"}), 400

    users = load_users()
    if any(u["name"] == name for u in users):
        return jsonify({"ok": False, "error": "A user with that name already exists"}), 400

    password = data.get("password") or generate_password()
    new_user = {
        "name": name,
        "auth_str": f"{name}:{password}",
        "created_at": datetime.utcnow().isoformat() + "Z",
        "enabled": True,
    }
    users.append(new_user)
    save_users(users)
    return jsonify({"ok": True, "user": new_user})


@app.route("/api/users/<name>", methods=["DELETE"])
@login_required
def api_users_delete(name):
    users = load_users()
    remaining = [u for u in users if u["name"] != name]
    if len(remaining) == len(users):
        return jsonify({"ok": False, "error": "User not found"}), 404
    save_users(remaining)
    return jsonify({"ok": True})


@app.route("/api/users/<name>/toggle", methods=["POST"])
@login_required
def api_users_toggle(name):
    users = load_users()
    found = False
    for u in users:
        if u["name"] == name:
            u["enabled"] = not u.get("enabled", True)
            found = True
    if not found:
        return jsonify({"ok": False, "error": "User not found"}), 404
    save_users(users)
    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=9090)
