#!/bin/bash
set -e

echo "== Hysteria 1 Panel Installer =="
echo "This assumes Hysteria is already installed at /usr/local/bin/hysteria"
echo "and its config lives at /etc/hysteria/config.json (as set up earlier)."
echo

PANEL_DIR="/opt/hysteria-panel"
HY_DIR="/etc/hysteria"

echo "== Installing Python + pip if needed =="
apt update -y
apt install -y python3 python3-venv python3-pip

echo "== Copying panel files to $PANEL_DIR =="
mkdir -p "$PANEL_DIR"
cp -r ./* "$PANEL_DIR"/

echo "== Creating virtualenv and installing Flask =="
cd "$PANEL_DIR"
python3 -m venv venv
./venv/bin/pip install --quiet flask

echo "== Backing up existing config.json =="
cp "$HY_DIR/config.json" "$HY_DIR/config.json.bak.$(date +%s)"

echo "== Migrating existing single-user credential into users.json =="
if [ ! -f "$HY_DIR/users.json" ]; then
  cat > "$HY_DIR/users.json" << 'EOF'
{
  "users": [
    {
      "name": "admin",
      "auth_str": "admin:adminx",
      "created_at": "migrated",
      "enabled": true
    }
  ]
}
EOF
  echo "Created users.json with your existing admin:adminx credential preserved."
else
  echo "users.json already exists, leaving it as-is."
fi

echo "== Rewriting Hysteria config.json to use external (multiuser) auth =="
python3 - << 'PYEOF'
import json

with open("/etc/hysteria/config.json") as f:
    cfg = json.load(f)

cfg["auth"] = {
    "mode": "external",
    "config": {
        "http": "http://127.0.0.1:9091/verify"
    }
}

with open("/etc/hysteria/config.json", "w") as f:
    json.dump(cfg, f, indent=2)

print("config.json updated to external auth mode.")
PYEOF

echo "== Creating systemd service for the auth server =="
cat > /etc/systemd/system/hysteria-auth.service << EOF
[Unit]
Description=Hysteria Auth Server (multiuser)
After=network.target

[Service]
Type=simple
ExecStart=$PANEL_DIR/venv/bin/python3 $PANEL_DIR/auth-server.py
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

echo "== Creating systemd service for the web panel =="
cat > /etc/systemd/system/hysteria-panel.service << EOF
[Unit]
Description=Hysteria Management Panel
After=network.target

[Service]
Type=simple
WorkingDirectory=$PANEL_DIR
ExecStart=$PANEL_DIR/venv/bin/python3 $PANEL_DIR/app.py
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

echo "== Reloading systemd and starting services =="
systemctl daemon-reload
systemctl enable --now hysteria-auth.service
systemctl enable --now hysteria-panel.service
systemctl restart hysteria-server.service

echo
echo "== Done =="
echo "Panel is running on 127.0.0.1:9090 (local only, not exposed to the internet)."
echo "Default login: admin / changeme  <-- CHANGE THIS in $PANEL_DIR/app.py, then:"
echo "  systemctl restart hysteria-panel.service"
echo
echo "To reach the panel from your browser, set up an SSH tunnel:"
echo "  ssh -L 9090:127.0.0.1:9090 root@<your-vps-ip>"
echo "Then open http://127.0.0.1:9090 in your own browser."
echo
systemctl status hysteria-auth.service --no-pager
systemctl status hysteria-panel.service --no-pager
systemctl status hysteria-server.service --no-pager
