#!/usr/bin/env bash
# UDP Custom Panel — clean reinstall / upgrade script
# - Removes any existing Node.js/npm install first
# - Installs a fresh current Node.js LTS (20.x) from NodeSource
# - Deploys the fixed panel files (server.js + public/)
# - Installs npm dependencies
# - Restarts the systemd service
set -euo pipefail

PANEL_DIR="/opt/udp-custom-panel"
NODE_MAJOR="20"

if [ "$(id -u)" -ne 0 ]; then
  echo "Please run this script as root (sudo bash install.sh)" >&2
  exit 1
fi

echo "==> Stopping panel service (if running)..."
systemctl stop udp-custom-panel 2>/dev/null || true

echo "==> Checking for existing Node.js/npm installation..."
if command -v node >/dev/null 2>&1; then
  echo "    Found: $(node -v) at $(command -v node)"
else
  echo "    No existing Node.js found."
fi

echo "==> Removing existing Node.js/npm (apt + nodesource leftovers)..."
apt-get remove -y --purge nodejs npm libnode-dev libnode72 >/dev/null 2>&1 || true
apt-get autoremove -y >/dev/null 2>&1 || true
rm -rf /usr/lib/node_modules /usr/local/lib/node_modules /usr/local/bin/node /usr/local/bin/npm
rm -f /etc/apt/sources.list.d/nodesource.list

echo "==> Installing Node.js ${NODE_MAJOR}.x LTS from NodeSource..."
apt-get update -y
apt-get install -y ca-certificates curl gnupg
curl -fsSL https://deb.nodesource.com/setup_${NODE_MAJOR}.x | bash -
apt-get install -y nodejs

echo "==> Verifying installed versions:"
node -v
npm -v

echo "==> Deploying panel files to ${PANEL_DIR}..."
mkdir -p "${PANEL_DIR}/public"
cp -f "$(dirname "$0")/server.js" "${PANEL_DIR}/server.js"
cp -f "$(dirname "$0")/public/app.js" "${PANEL_DIR}/public/app.js"
# index.html and style.css are left untouched if already present; copy only if missing
[ -f "${PANEL_DIR}/public/index.html" ] || cp -f "$(dirname "$0")/public/index.html" "${PANEL_DIR}/public/index.html" 2>/dev/null || true
[ -f "${PANEL_DIR}/public/style.css" ] || cp -f "$(dirname "$0")/public/style.css" "${PANEL_DIR}/public/style.css" 2>/dev/null || true

echo "==> Installing npm dependencies..."
cd "${PANEL_DIR}"
if [ -f package.json ]; then
  npm install --omit=dev
else
  npm init -y >/dev/null
  npm install express systeminformation
fi

echo "==> Restarting panel service..."
systemctl daemon-reload
systemctl enable udp-custom-panel 2>/dev/null || true
systemctl restart udp-custom-panel

sleep 2
echo "==> Service status:"
systemctl status udp-custom-panel --no-pager -l || true

echo ""
echo "Done. Node $(node -v) is now installed and the panel has been redeployed."
echo "Check logs with: journalctl -u udp-custom-panel -n 50 --no-pager"
