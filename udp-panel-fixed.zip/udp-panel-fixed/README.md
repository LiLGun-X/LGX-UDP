# UDP Custom Panel — Fixed Package

## What's in here
- `install.sh` — removes any existing Node.js/npm, installs fresh Node 20 LTS, deploys the files below, installs deps, restarts the service.
- `server.js` — fixed backend.
- `public/app.js` — fixed frontend.
- `public/index.html` — your existing HTML, copied through unchanged (not modified).
- `public/style.css` — **not included**. I never received this file's contents, so it wasn't touched. Your existing one on the server will be left in place by the install script (it only copies index.html/style.css if they're missing).

## What was actually broken and what changed

### 1. Auth was completely disabled (security issue, not just a bug)
`server.js` had two auth functions: a real one (`authREAL`, checking session tokens) and a debug one (`auth`, which just faked an admin session for anyone, no token needed) — but every route was wired to the debug one. That means the panel was reachable by **anyone who could hit the port**, with full admin rights: create/delete VPN users, read logs, change the panel password, and reboot the VPS.

Fix: removed the fake `auth` function and renamed `authREAL` to `auth`, so every route now genuinely checks the session token. This is a real behavior change — **you must log in normally now.** No config changes needed on your end.

### 2. Node.js version too old (the SyntaxError from before)
`authREAL` (and the `users()` function) use optional chaining (`?.`), which needs Node 14+. Your server was on something older (Node 10 or earlier, based on the internal stack trace format). `install.sh` removes any existing Node/npm install and installs Node 20 LTS fresh from NodeSource, so this won't come back.

### 3. Sidebar/menu appeared stuck
Two compounding bugs in `app.js`:
- A leftover debug snippet forced a fake `token="debug"` into `localStorage` and called `showApp()` unconditionally on every page load — bypassing login and then immediately hitting 401s from every API call (since `"debug"` isn't a real session), which triggered a logout loop. Removed.
- The `page()` function never updated which nav button had the `active` class, and never closed the mobile sidebar overlay after a menu item was picked. Both fixed — clicking a menu item now switches the visible section, highlights the right button, and closes the sidebar on mobile.

## How to deploy

```bash
# On the server, as root:
cd /path/to/wherever/you/unzipped/this
chmod +x install.sh
sudo bash install.sh
```

The script is safe to re-run. It will stop the service, strip out old Node/npm, install Node 20, copy in the fixed `server.js` and `app.js`, run `npm install`, and restart the service.

## After deploying
- Clear the site's local storage once in your browser (old fake token may still be cached): DevTools Console → `localStorage.removeItem("udp_panel_token")` — or just use "Clear site data" for the domain — then reload and log in normally.
- Watch the service come up: `journalctl -u udp-custom-panel -n 50 --no-pager`

## Not included / not verified in this pass
- `package.json` — I never saw its contents. `install.sh` will `npm install` from it if present, or fall back to installing `express` + `systeminformation` directly if not. Worth checking this matches what you actually had.
- `style.css` — untouched, not reviewed.
- The banner/VPN-connection-message feature — dropped per your request, not included here.
